package com.example.bank_bot

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
